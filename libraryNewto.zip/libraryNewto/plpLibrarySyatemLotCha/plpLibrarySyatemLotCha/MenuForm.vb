﻿Imports System.Data.OleDb

Public Class MenuForm
    Dim con As New OleDbConnection
    Dim x As New ErrorProvider
    Dim ds As DataSet
    Dim da As OleDbDataAdapter
    Dim dv As DataView
    Private Sub LogInToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogInToolStripMenuItem.Click
        Log_In.Show()
        Log_In.UserName.Text = ""
        Log_In.Password.Text = ""
        Txt1.Enabled = False
        Txttitle1.Enabled = False
        Txtauthor1.Enabled = False
        Txtabstract.Enabled = False
        ComboBox1.Enabled = False
        Txttitle.Enabled = False
        Tstauthor.Enabled = False
        Txtisbn.Enabled = False
        Button2.Enabled = False
        ListView1.Enabled = False
        AddToCard.Enabled = False
        BindingNavigator1.Enabled = False
        DataGridView1.Enabled = False
        Txtavail.Enabled = False
        DataGridView1.Hide()
        ListView1.Hide()

    End Sub
    Private Sub LogOutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogOutToolStripMenuItem.Click
        If MessageBox.Show("Are you sure you want to Sign Out", "Sign Out Windows", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Me.BorrowTransactionToolStripMenuItem.Enabled = False
            Me.ReturnTransactionToolStripMenuItem.Enabled = False
            Me.AdminUtilitiesToolStripMenuItem.Enabled = False
            Me.LogOutToolStripMenuItem.Enabled = False
            Me.LogInToolStripMenuItem.Enabled = True
            DataGridView1.Hide()
            ListView1.Hide()
            AddToCard.Enabled = False
            greetings.Text = "Welcome Guests"
            greeting1.Hide()
            greeting2.Hide()
            greetings3.Hide()
        End If
    End Sub
    Private Sub MenuForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the '_Charina_RoseDataSet.tblbook' table. You can move, or remove it, as needed.
        Me.TblbookTableAdapter.Fill(Me._Charina_RoseDataSet.tblbook) 
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\mhelot gibe\Documents\libraryNewto\Charina&Rose.mdb"
        Me.BorrowTransactionToolStripMenuItem.Enabled = False
        Me.ReturnTransactionToolStripMenuItem.Enabled = False
        Me.AdminUtilitiesToolStripMenuItem.Enabled = False
        Me.LogOutToolStripMenuItem.Enabled = False
        DataGridView1.Hide()
        AddToCard.Enabled = False
        ComboBox1.Items.Add("All")
        ComboBox1.Items.Add("English")
        ComboBox1.Items.Add("Mathematics")
        ComboBox1.Items.Add("Programming")
        ComboBox1.Items.Add("Science")
        ComboBox1.Items.Add("Social Science")
        ComboBox1.SelectedItem = ComboBox1.Items(0)
        greeting1.Hide()
        greeting2.Hide()
        greetings3.Hide()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\mhelot gibe\Desktop\libraryNewto\Charina&Rose.mdb"
        DataGridView1.Show()
        Dim da As New OleDbDataAdapter
        Dim dc As New DataTable
        If ComboBox1.Text = "All" Then
            da = New OleDbDataAdapter("select * from tblbook where Title like '%" & Txttitle.Text & _
          "%' and Author like '%" & Tstauthor.Text & "%' and ISBN like '%" & Txtisbn.Text & "%'", con)
            da.Fill(dc)
            DataGridView1.DataSource = dc
            DataGridView1.Show()
        ElseIf ComboBox1.Text = "English" Then
            Call book()
            Call book1()
        ElseIf ComboBox1.Text = "Mathematics" Then
            Call book()
            Call book1()
        ElseIf ComboBox1.Text = "Programming" Then
            Call book()
            Call book1()
        ElseIf ComboBox1.Text = "Science" Then
            Call book()
        ElseIf ComboBox1.Text = "Social Science" Then
            Call book()
            Call book1()
        Else : da = New OleDbDataAdapter("select * from tblbook where Title like '%" & Txttitle.Text & _
          "%' and Author like '%" & Txtauthor1.Text & "%' and ISBN like '%" & Txtisbn.Text & _
          "'", con)
            da.Fill(dc)
            DataGridView1.DataSource = dc
            DataGridView1.Show()
        End If
    End Sub
    Private Sub book()
        Dim da As New OleDbDataAdapter
        Dim dc As New DataTable
        da = New OleDbDataAdapter("select * from tblbook where Category like '" & ComboBox1.SelectedItem & "'", con)
        da.Fill(dc)
        DataGridView1.DataSource = dc
        ComboBox1.SelectedText = ""
    End Sub
    Private Sub book1()
        ComboBox1.Text = "All"
    End Sub
    Private Sub AddToCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToCard.Click
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter
        If Txt1.Text = "" Or Txtauthor1.Text = "" Or Txttitle1.Text = "" Or Txtabstract.Text = "" Or Txtavail.Text = "" Then
        Else : da = New OleDbDataAdapter("select * from tblbook where ISBN like '" & Txt1.Text & "'", con)
            da.Fill(dt)
            Dim myRow As DataRow
            For Each myRow In dt.Rows
                ListView1.Items.Add(myRow.Item(0))
                ListView1.Items(ListView1.Items.Count - 1).SubItems.Add(myRow.Item(1))
                ListView1.Items(ListView1.Items.Count - 1).SubItems.Add(myRow.Item(2))
                ListView1.Items(ListView1.Items.Count - 1).SubItems.Add(myRow.Item(3))
                ListView1.Items(ListView1.Items.Count - 1).SubItems.Add(myRow.Item(6))
                con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\mhelot gibe\Desktop\libraryNewto\Charina&Rose.mdb"
                con.Open()
                con.Close()
            Next
        End If

        End If
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        datenow.Text = DateString
        time.Text = TimeOfDay
    End Sub
    '        If Txttitle.Text = "" Then
    '        Else : da = New OleDbDataAdapter("select * from tblbook where Title like '" & Txttitle.Text & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            Txttitle.Text = ""
    '            Txttitle.Focus()
    '        End If
    '        If Txtisbn.Text = "" Then
    '        Else : da = New OleDbDataAdapter("select * from tblbook where ISBN like '" & Txtisbn.Text & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            Txtisbn.Text = ""
    '            Txtisbn.Focus()
    '        End If
    '        If Tstauthor.Text = "" Then
    '        Else : da = New OleDbDataAdapter("select * from tblbook where Author like '" & Tstauthor.Text & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            Tstauthor.Text = ""
    '            Tstauthor.Focus()
    '        End If
    '        Dim var As String
    '        var = ComboBox1.Text
    '        If ComboBox1.SelectedItem = ("All") Then
    '            con.Open()
    '            datagridShow()
    '            ComboBox1.SelectedText = ""
    '        ElseIf ComboBox1.SelectedItem = ("English") Then
    '            da = New OleDbDataAdapter("select * from tblbook where Category like '" & ComboBox1.SelectedItem & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            ComboBox1.SelectedText = ""
    '        ElseIf ComboBox1.SelectedItem = ("Mathematics") Then
    '            da = New OleDbDataAdapter("select * from tblbook where Category like '" & ComboBox1.SelectedItem & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            ComboBox1.SelectedText = ""
    '        ElseIf ComboBox1.SelectedItem = ("Programming") Then
    '            da = New OleDbDataAdapter("select * from tblbook where Category like '" & ComboBox1.SelectedItem & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            ComboBox1.SelectedText = ""
    '        ElseIf ComboBox1.SelectedItem = ("Science") Then
    '            da = New OleDbDataAdapter("select * from tblbook where Category like '" & ComboBox1.SelectedItem & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            ComboBox1.SelectedText = ""
    '        ElseIf ComboBox1.SelectedItem = ("Social Science") Then
    '            da = New OleDbDataAdapter("select * from tblbook where Category like '" & ComboBox1.SelectedItem & "'", con)
    '            da.Fill(dc)
    '            DataGridView1.DataSource = dc
    '            ComboBox1.SelectedText = ""
    '        Else
    '        End If
    'End Sub
    'Private Sub datagridShow()
    '    Dim da As New DataSet
    '    Dim db As New DataTable
    '    da.Tables.Add(db)
    '    Dim dc As New OleDbDataAdapter
    '    dc = New OleDbDataAdapter("select * from tblbook", con)
    '    dc.Fill(db)
    '    DataGridView1.DataSource = db.DefaultView
    '    con.Close()

  
    
End Class
