﻿Imports System.Data.OleDb
Public Class Log_In
    Dim con As New OleDbConnection
    Dim ds As DataSet
    Dim da As OleDbDataAdapter
    Dim dv As DataView

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If ask() = True Then
            MenuForm.Show()
            Me.Hide()
        ElseIf UserName.Text = "" And Password.Text = "" Then
            MsgBox("Please enter username and password", MsgBoxStyle.Exclamation, "Log In")
        ElseIf Password.Text = "" Then
            MsgBox("Please enter UserName", MsgBoxStyle.Exclamation, "Log In")
        ElseIf Password.Text = "" Then
            MsgBox("Please enter Password", MsgBoxStyle.Exclamation, "Log In")
        Else
            MsgBox("Sorry invalid Password!", MsgBoxStyle.Exclamation, "Log In")
            UserName.Text = ""
            UserName.Text = ""
            Password.Text = ""
            Password.Text = ""
            MenuForm.Text = ""
        End If 
        If MenuForm.greetings.Text = "Admin" Then
            MenuForm.AddToCard.Enabled = False
        ElseIf MenuForm.greetings.Text = "Member" Then
            MenuForm.AddToCard.Enabled = True
        End If
        MenuForm.LogInToolStripMenuItem.Enabled = False
        MenuForm.BorrowTransactionToolStripMenuItem.Enabled = True
        MenuForm.ReturnTransactionToolStripMenuItem.Enabled = True
        MenuForm.AdminUtilitiesToolStripMenuItem.Enabled = True
        MenuForm.LogOutToolStripMenuItem.Enabled = True
        MenuForm.Txt1.Enabled = True
        MenuForm.Txttitle1.Enabled = True
        MenuForm.Txtauthor1.Enabled = True
        MenuForm.Txtabstract.Enabled = True
        MenuForm.ComboBox1.Enabled = True
        MenuForm.Txttitle.Enabled = True
        MenuForm.Tstauthor.Enabled = True
        MenuForm.Txtisbn.Enabled = True
        MenuForm.Button2.Enabled = True
        MenuForm.ListView1.Enabled = True
        MenuForm.BindingNavigator1.Enabled = True
        MenuForm.DataGridView1.Enabled = True
        MenuForm.ListView1.Show()

    End Sub
    Public Function ask()
        Dim dt As New DataTable
        Dim ds As New DataSet
        ds.Tables.Add(dt)
        con.Open()
        Dim da As New OleDbDataAdapter("select * From tblmember", con)
        da.Fill(dt)
        For Each datarow In dt.Rows
            If UserName.Text = datarow.item(2) And Password.Text = datarow(3) Then
                MenuForm.greetings.Text = datarow.item(5)
                MenuForm.greeting2.Text = datarow.item(1)

                Call greetingname()
                con.Close()
                Return True   
            End If
        Next
        con.Close()
        Return False
    End Function
    Private Sub Log_In_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\mhelot gibe\Desktop\libraryNewto\Charina&Rose.mdb"
    End Sub
    Private Sub UserName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles UserName.KeyDown
        If e.KeyCode = Keys.Delete And Keys.Back Then
            UserName.Text = ""
           End If
    End Sub
    Private Sub Password_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Password.KeyDown
        If e.KeyCode = Keys.Delete And Keys.Back Then
            UserName.Text = ""
        End If
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        UserName.Text = ""
        Password.Text = ""
        MenuForm.Txt1.Enabled = True
        MenuForm.Txttitle1.Enabled = True
        MenuForm.Txtauthor1.Enabled = True
        MenuForm.Txtabstract.Enabled = True
        MenuForm.ComboBox1.Enabled = True
        MenuForm.Txttitle.Enabled = True
        MenuForm.Tstauthor.Enabled = True
        MenuForm.Txtisbn.Enabled = True
        MenuForm.Button2.Enabled = True
        MenuForm.ListView1.Enabled = True
        MenuForm.AddToCard.Enabled = True
        MenuForm.BindingNavigator1.Enabled = True
        MenuForm.DataGridView1.Enabled = True
        MenuForm.Txtavail.Enabled = True
        MenuForm.AddToCard.Enabled = False
        MenuForm.ListView1.Enabled = False

    End Sub
    Private Sub greetingname()
        MenuForm.greeting1.Text = "you are LOG IN as "
        MenuForm.greetings3.Text = "Welcome "
        MenuForm.greeting1.Show()
        MenuForm.greeting2.Show()
        MenuForm.greetings3.Show()
    End Sub

End Class